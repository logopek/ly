import flask

app = flask.Flask(__name__)

@app.route('/')
def redir():
    return flask.redirect('/astronaut_selection')
@app.route('/astronaut_selection')
def what():
    return flask.render_template('index.html')


if __name__ == '__main__':
    app.run(host="127.0.0.1", port=8080)
